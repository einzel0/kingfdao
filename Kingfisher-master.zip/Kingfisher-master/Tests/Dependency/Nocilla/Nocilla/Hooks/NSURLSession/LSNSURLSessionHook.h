//
//  LSNSURLSessionHook.h
//  Nocilla
//
//  Created by Luis Solano Bonet on 08/01/14.
//  Copyright (c) 2014 Luis Solano Bonet. All rights reserved.
//

#import "Nocilla.h"

#import "LSHTTPClientHook.h"

@interface LSNSURLSessionHook : LSHTTPClientHook

@end
